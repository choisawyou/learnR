setwd('C:/Users/qlswl/Desktop/lastTeam')

cc <-  read.csv('연령별 창업.csv')
cc<- cc[,-1]


barplot(as.matrix(cc),mmain = '연령별 창업',ylab='단위 %',beside=T, col=rainbow(5),ylim=c(0,100))
legend('top',c('20대 이하', '30대','40대','50대','60대 이하'),cex=0.8,fill=rainbow(5))

