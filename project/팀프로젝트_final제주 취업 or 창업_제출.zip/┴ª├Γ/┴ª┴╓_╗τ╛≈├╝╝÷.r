setwd( "D:/WorkR")
jeju_indus_company_all <- read.csv( "제주_산업별_총사업체수_1.csv", header = T)

#View(jeju_indus_company_all)
#str(jeju_indus_company_all)


library(ggplot2)
library(dplyr)






View(compa_num)

# 제주 전체 산업별 기업체수 

ggplot(data=jeju_indus_company_all, aes(x=연도별, y=사업체수, color=산업별)) +
  geom_line() + theme_classic() + ggtitle('도내 산업별 사업체 수 현황')
  #lwd=2geom_line() 

 
# 제주 상위 산업 
jeju_indus_company_all$사업체수 <- as.numeric(jeju_indus_company_all$사업체수)  
jeju_a <- jeju_indus_company_all %>% filter(jeju_indus_company_all$사업체수> 5000) 

ggplot(data=jeju_a, aes(x=연도별, y=사업체수, color=산업별)) +
  geom_line()+ theme_classic()+ ggtitle('도내 상위 사업체수 산업')



# 상위 산별별 기업체수

jeju_indus_company_all$사업체수 <- as.numeric(jeju_indus_company_all$사업체수)  
jeju_a <- jeju_indus_company_all %>% filter(jeju_indus_company_all$사업체수> 10000) 

ggplot(data=jeju_a, aes(x=연도별, y=사업체수, color=산업별)) +
  geom_line()+ theme_classic() + ggtitle('도소매업 및 숙박 음식점업의 사업체수')


# 중위 산업별 기업체수 

jeju_indus_company_all$사업체수 <- as.numeric(jeju_indus_company_all$사업체수)  
jeju_b <- jeju_indus_company_all %>% filter(jeju_indus_company_all$사업체수<10000 & jeju_indus_company_all$사업체수 > 5000)

ggplot(data=jeju_b, aes(x=연도별, y=사업체수, color=산업별)) +
  geom_line()+ theme_classic() + ggtitle('운수업 및 기타 개인서비스업')

# 하위 산업별  기업체수 

jeju_indus_company_all$사업체수 <- as.numeric(jeju_indus_company_all$사업체수)  
jeju_c <- jeju_indus_company_all %>% filter(jeju_indus_company_all$사업체수< 5000 )

ggplot(data=jeju_c, aes(x=연도별, y=사업체수, color=산업별)) +
  geom_line()+ theme_classic()


# 하위  상 산업별 기업체수


jeju_indus_company_all$사업체수 <- as.numeric(jeju_indus_company_all$사업체수)  
jeju_d <- jeju_indus_company_all %>% filter(jeju_indus_company_all$사업체수> 900 & jeju_indus_company_all$사업체수<4000 )

ggplot(data=jeju_d, aes(x=연도별, y=사업체수, color=산업별)) +
  geom_line()+ theme_classic()

# 하위 하 산업별 기업체수

jeju_indus_company_all$사업체수 <- as.numeric(jeju_indus_company_all$사업체수)  
jeju_e <- jeju_indus_company_all %>% filter(jeju_indus_company_all$사업체수 < 900  )

ggplot(data=jeju_e, aes(x=연도별, y=사업체수, color=산업별)) +
  geom_line()+ theme_classic()


